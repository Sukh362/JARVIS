Jarvis (Cordova) — Starter README
====================================

1) Prereqs
   - Node.js LTS installed
   - Java JDK 17 installed
   - Android Studio installed + SDK Platform (API 34+), Build-Tools, Command-line Tools, Platform-Tools
   - Environment vars: JAVA_HOME and ANDROID_HOME (plus add platform-tools, build-tools, cmdline-tools/latest/bin to PATH)

2) Create Cordova project (do this outside this folder):
   npm i -g cordova
   cordova create jarvisApp com.example.jarvis "Jarvis"
   cd jarvisApp
   cordova platform add android

3) Add plugins:
   cordova plugin add cordova-plugin-speechrecognition
   cordova plugin add cordova-plugin-tts
   cordova plugin add cordova-plugin-inappbrowser

4) Copy the files from this starter into your project's www/ folder (replace existing index.html, add css/ and js/)

5) Build & run:
   cordova build android
   cordova run android --device

6) Notes:
   - Voice recognition uses the native plugin (not Web Speech API).
   - Text-to-speech uses the TTS plugin; in browser preview it falls back to SpeechSynthesis if available.
   - For Hindi default, change 'en-IN' to 'hi-IN' in app.js startListening() and speak() calls.
